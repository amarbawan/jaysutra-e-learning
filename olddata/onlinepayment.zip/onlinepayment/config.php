<?php
    
    $razor_pay_key_id = 'rzp_live_cA7LdjgPoP78fA';
    $secret_key = 'gf65RyKw6znByE5X8PLUKwCN';
    define("KEY",$razor_pay_key_id);
    define("API_SECRET",$secret_key);
?>