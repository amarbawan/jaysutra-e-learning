<?php include('templates/header.php'); ?>
<section class="showcase">
   <div class="container">
    <div class="text-center">
      <h1 class="display-3">Thank You!</h1>
      <p class="lead">Your payment has been received successfully.</p>
      <hr>
      <p>
        Having trouble? <a href="mailto:helpdesk@jaysutra.com">Contact us</a>
      </p>
      <p class="lead">
        <a class="btn btn-primary btn-sm" href="#" role="button">Continue to homepage</a>
      </p>
    </div>
    </div>
</section>
<br><br><br><br><br><br>
<?php include('templates/footer.php');?>