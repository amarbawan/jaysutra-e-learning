<?php
// credential
define('RAZOR_KEY_ID', 'rzp_live_cA7LdjgPoP78fA');
define('RAZOR_KEY_SECRET', 'gf65RyKw6znByE5X8PLUKwCN');

?>
