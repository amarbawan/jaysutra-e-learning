
<?php include("inc/function.php");?>
<div id="header">

	<div id="logo">
		<h2><a href="index.php" >JaySutra</a></h2>
	
	</div>
	<div id="title">
	<h2>JaySutra Learning Mangement System (Admin)</h2>
	
	</div>   
	<div id="link">
		<h3><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></h3>
		
	</div>
	

</div>