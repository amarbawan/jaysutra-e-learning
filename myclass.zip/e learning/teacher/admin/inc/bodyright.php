<?php if(!isset($_GET['viewallstudent'])&&!isset($_GET['viewallteacher'])&&!isset($_GET['lecture'])&&!isset($_GET['add_course'])&&!isset($_GET['about'])&&!isset($_GET['faqs'])&&!isset($_GET['contact'])&&!isset($_GET['cat'])&&!isset($_GET['sub_cat'])&&!isset($_GET['lang'])&&!isset($_GET['terms'])){?>
<div id="bodyright">


	<h3>OverView</h3>
	
		<ul>
			<li style="margin-left:0px;background:#33BBFF;"><b>5</b><p>Total <br>categories</p>
			
			<i class="fas fa-th"></i><br>
			
			<a href="#" style="background:#D9DEE1;">View More</a>
			
			</li>
			
			<li style="background:#17850A;"><b>5</b><p >Total Sub<br>categories</p>
			<i class="fas fa-stream" style="color:#35BE09;"></i>
			<br>
			
			<a href="#" style="background:#35BE09;">View More</a>
			
			</li>
			<li style="background:#F74406;"><b>5</b><p>Total <br>Students</p>
			
			<i class="fas fa-users" style="color:#9A2D07;"></i><br>
			
			<a href="#" style="background:#9A2D07;">View More</a>
			
			</li><li style="background:#0652F6;"><b>5</b><p>Total <br>Teachers</p>
			<i class="fas fa-users" style="color:#7FD3A9;"></i><br>
			
			<a href="#" style="background:#7FD3A9;">View More</a>
			
			</li><li style="background:#FB7A00;"><b>5</b><p>Active <br>Courses</p>
			
			<i class="fab fa-creative-commons-sampling" style="color:#754417;"></i><br/>
			
			<a href="#" style="background:#754417;">View More</a>
			
			</li>
			<li style="margin-left:0px;background:#3B2F23;"><b>5</b><p>Pendding <br>Courses</p>
			
			<i class="fas fa-ban"></i><br>
			
			<a href="#" style="background:#D9DEE1;color:#3B2F23;">View More</a>
			
			</li>
			<li style="background:#7E2722;"><b>5</b><p>Unpublish <br>Courses</p>
			
			<i class="fas fa-book" style="color:#472220;"></i><br>
			
			<a href="#" style="background:#472220;">View More</a>
			
			</li>
			<li style="background:#F503B7;"><b>5</b><p>Pendding <br>Payments</p>
			
			<i class="fas fa-dollar-sign" style="color:#D1CACA;"></i><br>
			
			<a href="#" style="background:#D1CACA;opacity:1;">View More</a>
			
			</li><li style="background:#B97FEA;"><b>5</b><p>Complete <br>Payments</p>
			
			<i class="fas fa-dollar-sign" style="color:#A747F7;"></i><br>
			
			<a href="#" style="background:#A747F7;">View More</a>
			
			</li><li style="background:#1A7ADB;"><b style="visibility:hidden;">5</b><p>Contact <br>Us</p>
			
			<i class="fas fa-phone-volume"></i><br>
			
			<a href="#" style="background:#D9DEE1;">View More</a>
			
			</li>
			
			<li style="margin-left:0px;background:#3f5267;"><b style="visibility:hidden;">5</b><p>About <br>Us</p>
			
			<i class="fas fa-info-circle" style="color:#74889e;"></i><br>
			
			<a href="#" style="background:#74889e;">View More</a>
			
			</li>
			<li style="background:#4A1656;"><b style="visibility:hidden;">5</b><p>Terms & <br>Conditions</p>
		
			<i class="fas fa-check-circle" style="color:#CB08F7;"></i><br>
			
			<a href="#" style="background:#CB08F7;">View More</a>
			
			</li>
			<li style="background:#514E52;"><b style="visibility:hidden;">5</b><p>FAQs <br>Management</p>
			
			<i class="fas fa-question-circle" style="color:#B5ADB7;"></i><br>
			
			<a href="#" style="background:#B5ADB7;opacity:1;">View More</a>
			
			</li><li style="background:#0BF759;"><b style="visibility:hidden;">5</b><p>Slider <br>Management</p>
			<i class="far fa-images"></i>
			<i class="far fa-images" style="color:#3B9258;"></i><br>
			
			<a href="#" style="background:#3B9258;">View More</a>
			
			</li>
		
		</ul>
	
	
	
	
</div>
<?php }?>