<div id="bodyleft_catmenu">

	<div id="blcat1">

		<h3>Category</h3>
		<?php echo cat_menu();?>
		
		<h3>Sub Category</h3>
		<?php echo sub_cat_menu();?>
	
	</div>
	
</div><br clear="all"/>