<div id="slider">

	<img src="imgs/slider/6.png" />



</div>