<div id="footer">
	
	<ul>
	
		<li>
			<h2><span>Abo</span>ut Us</h2>
			<p>We are a team of down-to-earth and Qualified Professionals who are not interested in making a quick buck.</p>
		</li>
		
		<li>
			<h2><span>Con</span>tact Us</h2>
				<div id="info">
					<i class="fas fa-map-marker-alt"></i>
					<p>Patna City-800008.</p>
				</div>
				<div id="info" style="margin-bottom:-10px;">
					<i class="fas fa-phone-square"></i>
					<p>NA</p>
				</div><br clear="all"/>
				<div id="info">
					<i class="fas fa-envelope"></i>
					<p>helpdesk@jaysutra.com</p>
				</div>
				<div id="f_share">
				<div id="fb">
					<a href="https://www.facebook.com/JaySutra4U/"><i class="fab fa-facebook-f"></i></a>
					
				</div>
				<div id="gp">
					<a href="https://www.instagram.com/jay.sutra/"><i class="fab fa-instagram"></i></a>
					
				</div>
				<div id="tw">
					<a href="https://twitter.com/jay_sutra"><i class="fab fa-twitter "></i></a>
				</div>
				<div id="gp">
					<a href="https://www.youtube.com/c/JaySutra"><i class="fab fa-youtube "></i></a>

				</div>
				</div>
			
		</li>
		
		<li>
			<h2><span>Lea</span>ve Your Massage</h2>
			
		
				<form mehtod="post">
					
				
					<div id="f_input">
				
						<i class="fa-user"></i>
						<input type="text" name="query_name"  placeholder="Enter Your Name" />

					</div>

					<div id="f_input">
					
						<i class=" fa-envelope"></i>
						<input type="text" name="query_email" placeholder="Enter Your Email" />

					</div>
			
					<textarea name="msg" placeholder="Enter Your Message"></textarea>
					
						<button>Send</button>
					
				</form>
				
		
		</li><br clear="all"/>
	
	</ul>
	<h3>© Copyright jaysutra.com 2020. All Rights Reserved</h3>
	
	
	
</div>