<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>JaySutra | Category</title>
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css"/>
	</head>
	<body>
		<?php

			include("inc/header.php");
			include("inc/bodyleft_catmenu.php");
			include("inc/bodyright_catmenu.php");
			include("inc/footer.php");
			
		?>	
		
	</body>
</html>
