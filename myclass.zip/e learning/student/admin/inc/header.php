
<?php include("inc/function.php");?>
<div id="header">

	<div id="logo">
		<h2><a href="index.php" >JaySutra</a></h2>
	
	</div>
	<div id="title">
	<h2>JaySutra Online Learning System (Student) </h2>
	
	</div>   
	<div id="link">
		<h3><a href="../../index.php"><i class="fas fa-running" style="margin-right:6px;font-size:25px;" ></i> <i class="fas fa-arrow-right" style="margin-right:6px;font-size:20px;"></i><i class="fas fa-home" style="margin-right:6px;font-size:25px;"></i></a></h3>
		
	</div>
	

</div>