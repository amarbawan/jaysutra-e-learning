<?php if(!isset($_GET['viewallteacher'])&&!isset($_GET['about'])&&!isset($_GET['mycourses'])&&!isset($_GET['contact'])&&!isset($_GET['cat'])&&!isset($_GET['sub_cat'])&&!isset($_GET['lang'])&&!isset($_GET['terms'])){?>
<div id="bodyright">


	<h3>OverView</h3>
</div>
<?php }?>