<div id="bodyright">


	<h3>Contact Us Page</h3>
		
		<div id="con">
		
			
			<?php echo contact();?>
		
		</div>
		
</div>

		<?php 
	//echo add_cat();
		?>